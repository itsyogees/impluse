'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${
      scrolled ? 'bg-bg-primary/95 backdrop-blur-xl' : 'bg-bg-primary/95'
    } border-b border-border`}>
      <div className="max-w-[1400px] mx-auto px-8 py-4 flex justify-between items-center">
        <Link href="/" className="font-cinzel text-3xl font-bold tracking-[3px] text-accent-gold">
          IMPULSE
        </Link>
        
        <ul className="hidden md:flex gap-10 items-center">
          <li><a href="#features" className="text-text-secondary hover:text-accent-gold transition font-medium text-sm">Features</a></li>
          <li><a href="#indicators" className="text-text-secondary hover:text-accent-gold transition font-medium text-sm">Indicators</a></li>
          <li><a href="#courses" className="text-text-secondary hover:text-accent-gold transition font-medium text-sm">Courses</a></li>
          <li><a href="#news" className="text-text-secondary hover:text-accent-gold transition font-medium text-sm">News</a></li>
          <li><a href="#about" className="text-text-secondary hover:text-accent-gold transition font-medium text-sm">About</a></li>
          <li><a href="#contact" className="text-text-secondary hover:text-accent-gold transition font-medium text-sm">Contact</a></li>
          <li>
            <Link 
              href="/dashboard" 
              className="border-2 border-accent-green px-7 py-2.5 rounded-md text-accent-green font-semibold hover:bg-accent-green hover:text-bg-primary transition"
            >
              Login
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  )
}
