'use client'

import Link from 'next/link'

export default function Hero() {
  return (
    <section className="min-h-screen flex items-center px-8 pt-32 pb-16 bg-gradient-to-br from-bg-primary to-bg-secondary relative overflow-hidden">
      <div className="absolute inset-0 bg-[linear-gradient(rgba(212,175,55,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(212,175,55,0.03)_1px,transparent_1px)] bg-[length:50px_50px] z-0" />
      
      <div className="max-w-[1400px] mx-auto text-center relative z-10">
        <div className="text-sm text-accent-gold uppercase tracking-[3px] mb-6">
          Premium Trading Education
        </div>
        
        <h1 className="font-cinzel text-7xl font-bold leading-tight mb-6">
          Master the Art of <span className="text-accent-gold">Trading</span>
        </h1>
        
        <p className="text-xl text-text-secondary max-w-[700px] mx-auto mb-12">
          Access professional-grade indicators, expert-led courses, and real-time market insights 
          to transform your trading journey.
        </p>
        
        <div className="flex gap-6 justify-center">
          <a 
            href="#enroll" 
            className="bg-accent-gold px-10 py-4 rounded-md text-bg-primary font-bold hover:translate-y-[-2px] hover:shadow-[0_10px_30px_rgba(212,175,55,0.3)] transition"
          >
            Start Learning
          </a>
          <a 
            href="#features" 
            className="border-2 border-accent-gold px-10 py-4 rounded-md text-accent-gold font-bold hover:bg-accent-gold hover:text-bg-primary transition"
          >
            Explore Features
          </a>
        </div>
      </div>
    </section>
  )
}
