'use client'

import DashboardContent from '@/components/sections/DashboardContent'

export default function Dashboard() {
  return (
    <DashboardContent />
  )
}
